
<?php   
    $usu = "estoess1_ElizabethCoronado2023";
	$contrasena = "TengoHambrehaha0";  
	$servidor = "estoessistemas.com";
	$basededatos = "estoess1_ElizabethCoronado2023";


	$conexion = mysqli_connect( $servidor, $usu, $contrasena ) or die ("No se ha podido conectar al servidor de Base de datos");
    $db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! Pues va a ser que no se ha podido conectar a la base de datos" );
  //echo "Correcto";  
  //echo $usu;
  
  
  
                                $ConsultaActivos="Select * from Usuario";
                                $Res=mysqli_query($conexion,$ConsultaActivos);
                                while($mostrarP=mysqli_fetch_assoc($Res)){ 
                                //$mostrarActivos=mysqli_fetch_assoc($Res);
                                $ID=$mostrarP['Id_Usuario'];
                                $noms=$mostrarP['Nombre'];
                                $apes=$mostrarP['Apellido'];
                                
                                echo $ID, $noms, $apes;
                                ?>
                                <br>
                                <?php
                                echo "<br>";
                                //echo "----------------";
                                }
                                
    mysqli_set_charset($conexion, 'utf8');
?>


<?php   
    $usu = "estoess1_ElizabethCoronado2023";
	$contrasena = "TengoHambrehaha0";  
	$servidor = "estoessistemas.com";
	$basededatos = "estoess1_ElizabethCoronado2023";


	$conexion = mysqli_connect( $servidor, $usu, $contrasena ) or die ("No se ha podido conectar al servidor de Base de datos");
    $db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! Pues va a ser que no se ha podido conectar a la base de datos" );
  //echo "Correcto";  
  //echo $usu;
  
  
  
                                $ConsultaActivos="Select * from Pagos";
                                $Res=mysqli_query($conexion,$ConsultaActivos);
                                while($mostrarP=mysqli_fetch_assoc($Res)){ 
                                //$mostrarActivos=mysqli_fetch_assoc($Res);
                                $cant=$mostrarP['Cantidad'];
                                $apes=$mostrarP['Apellido'];
                                echo $cant;
                                ?>
                                <br>
                                <?php
                                echo "<br>";
                                //echo "----------------";
                                }
                                
    mysqli_set_charset($conexion, 'utf8');
?>
