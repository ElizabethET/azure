<?php
    $usu = "estoess1_ElizabethCoronado2023";
    $contrasena = "TengoHambrehaha0";  
    $servidor = "estoessistemas.com";
    $basededatos = "estoess1_ElizabethCoronado2023";
    $conexion = mysqli_connect( $servidor, $usu, $contrasena ) or die ("No se ha podido conectar al servidor de Base de datos");
    $db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! Pues va a ser que no se ha podido conectar a la base de datos" );
    
       $Id_Usuario=$_POST['id'];
        $noms=$_POST['noms'];
        $apes=$_POST['apes'];

            $sentanciaCA="UPDATE Usuario SET Nombre = '$noms', Apellido = '$apes' WHERE Id_Usuario = '$Id_Usuario'";
            $ResultadoCA = mysqli_query($conexion, $sentanciaCA);
                
            echo '<script> alert("EL USUARIO '.$Id_Usuario.' HA SIDO ACTUALIZADO!");
            location.href = "menu.php";
            </script>';
?>