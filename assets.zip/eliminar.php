<?php
    $usu = "estoess1_ElizabethCoronado2023";
    $contrasena = "TengoHambrehaha0";  
    $servidor = "estoessistemas.com";
    $basededatos = "estoess1_ElizabethCoronado2023";
    $conexion = mysqli_connect( $servidor, $usu, $contrasena ) or die ("No se ha podido conectar al servidor de Base de datos");
    $db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! Pues va a ser que no se ha podido conectar a la base de datos" );
    
        $noms=$_POST['noms'];
        $apes=$_POST['apes'];

    //$id=$_POST['id'];
    $Id_Usuario=$_GET['Id_Us'];

            //BORRA LOS DATOS DEL USUARIO SOLICITANTE
            $sentanciaCA="DELETE FROM Usuario WHERE Id_Usuario = '$Id_Usuario'";
            $ResultadoCA = mysqli_query($conexion, $sentanciaCA);
                
            echo '<script> alert("EL USUARIO '.$Id_Usuario.' HA SIDO ELIMINADO!");
            location.href = "index.php";
            </script>';
        
?>