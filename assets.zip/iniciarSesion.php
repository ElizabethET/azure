<?php
    $usu = "estoess1_ElizabethCoronado2023";
    $contrasena = "TengoHambrehaha0";  
    $servidor = "estoessistemas.com";
    $basededatos = "estoess1_ElizabethCoronado2023";
    $conexion = mysqli_connect( $servidor, $usu, $contrasena ) or die ("No se ha podido conectar al servidor de Base de datos");
    $db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! Pues va a ser que no se ha podido conectar a la base de datos" );
    
        $nom=$_POST['nom'];
        $cont=$_POST['cont'];

           $sentanciaCA="SELECT count(*) as Validar FROM Iniciar WHERE Nombre='$nom' and Contrasena='$cont'";
            $ResultadoCA = mysqli_query($conexion, $sentanciaCA);    
            $mostrarP=mysqli_fetch_assoc($ResultadoCA);
            $val = $mostrarP['Validar'];

             if($val==1){ 
                echo '<script> alert("Bienvenido Usuario '.$nom.'");
                location.href = "menu.php";
                </script>';
             }
             else{
                      
                echo '<script> alert("Usuario no Existe");
                location.href = "index.php";
                </script>';
            }
                
?>
                
           
