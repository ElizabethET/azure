<?php
    $usu = "estoess1_ElizabethCoronado2023";
    $contrasena = "TengoHambrehaha0";  
    $servidor = "estoessistemas.com";
    $basededatos = "estoess1_ElizabethCoronado2023";
    $conexion = mysqli_connect( $servidor, $usu, $contrasena ) or die ("No se ha podido conectar al servidor de Base de datos");
    $db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! Pues va a ser que no se ha podido conectar a la base de datos" );
    
        $noms=$_POST['noms'];
        $apes=$_POST['apes'];

    echo $noms;
    echo $apes;

  
            //INSERTA LOS DATOS DEL USUARIO SOLICITANTE
           $sentanciaCA="INSERT INTO Usuario (Nombre,Apellido) VALUES ('$noms','$apes')";
            $ResultadoCA = mysqli_query($conexion, $sentanciaCA);                                                                            
                
            echo '<script> alert("NUEVO USUARIO '.$noms.' REGISTRADO!");
            location.href = "index.php";
            </script>';
        
?>